# BUBBLR (^-^)/

- **Names**: 
  - Benjamin Bryant Budiman
  - Peter Lillian
  - Allegra Reister
  - Sophie Smith
  - Bixiao Yan
  
  - To run:
    - Import Bubblr.java in Eclipse
    - Run Bubblr.sql (included in zip) in MYSQL
    - Run Server.java
    - Run Main.java
    
 - Known bugs: 
   - The GamePlayGUI flickers sometimes
   - The high scores occasionally do not appear on the left side on the GamePlayGUI as they should 
